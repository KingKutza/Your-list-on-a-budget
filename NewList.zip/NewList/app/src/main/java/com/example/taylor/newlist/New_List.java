package com.example.taylor.newlist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class New_List extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new__list);
    }
}
