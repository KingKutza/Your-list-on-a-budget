package com.example.taylor.additem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Add_Item extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add__item);
    }
}
